document.addEventListener("click",function(e)
{
	let body=document.querySeletor('body');
	let bullet=document.createElement('span');
	let x=e.offsetX;
	let y=e.offsetY;
	bullet.style.left=x+'px';
	bullet.style.top=x+'px';
	body.appendchild(bullet);

	var audio=document.getElementId('audio');
	audio.play()
})